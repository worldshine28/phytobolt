import { useEffect, useState } from "react";

// Type declaration for AOS
declare global {
  interface Window {
    AOS: {
      init: (options?: any) => void;
      refresh: () => void;
    };
  }
}

interface FloatingParticleProps {
  delay?: number;
  duration?: number;
  top?: string;
}

const FloatingParticle = ({ delay = 0, duration = 15, top = "20%" }: FloatingParticleProps) => (
  <div
    className="floating-particle"
    style={{
      top,
      animationDelay: `${delay}s`,
      animationDuration: `${duration}s`,
    }}
  />
);

const HeroSection = () => {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="scroll-section ocean-gradient relative flex items-center justify-center overflow-hidden">
      {/* Floating particles */}
      <div className="absolute inset-0">
        <FloatingParticle delay={0} top="20%" />
        <FloatingParticle delay={-3} top="40%" />
        <FloatingParticle delay={-7} top="60%" />
        <FloatingParticle delay={-12} top="80%" />
      </div>

      {/* Wave animation */}
      <div className="wave-animation"></div>

      {/* Split background images */}
      <div className="absolute inset-0 flex">
        {/* Healthy ocean phytoplankton - left side */}
        <div className="w-1/2 relative">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent to-black opacity-50 z-10"></div>
          <img
            src="https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"
            alt="Bioluminescent ocean phytoplankton"
            className="w-full h-full object-cover opacity-60"
          />
        </div>

        {/* Polluted microplastic ocean - right side */}
        <div className="w-1/2 relative">
          <div className="absolute inset-0 bg-gradient-to-l from-transparent to-black opacity-50 z-10"></div>
          <img
            src="https://images.unsplash.com/photo-1621451537084-482c73073a0f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"
            alt="Ocean pollution with plastic waste"
            className="w-full h-full object-cover opacity-40"
          />
        </div>
      </div>

      {/* Content */}
      <div className="relative z-20 text-center px-4 max-w-4xl mx-auto" data-aos="fade-up" data-aos-duration="1000">
        <h1 className="font-poppins font-bold text-6xl md:text-8xl mb-6 glow-text animate-pulse-glow">
          PhytoBolt ⚡
        </h1>
        <h2 className="font-montserrat font-medium text-2xl md:text-3xl mb-4 text-cyan-100">
          Zapping Microplastics to Save the Ocean's Oxygen
        </h2>
        <p className="text-lg md:text-xl mb-8 text-gray-200 animate-float">
          🌍 <em>Half of every breath comes from the ocean</em>
        </p>
        <div className="text-sm text-cyan-200 mb-8">
          The invisible crisis threatening half of Earth's oxygen
        </div>
        <button
          onClick={() => scrollToSection("problem-section")}
          className="bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 glow-border transform hover:scale-105"
        >
          Learn the Truth 🌊
        </button>
      </div>
    </section>
  );
};

const ProblemSection = () => {
  return (
    <section
      id="problem-section"
      className="scroll-section relative flex items-center justify-center overflow-hidden"
      style={{ background: 'linear-gradient(135deg, hsl(215, 40%, 8%) 0%, hsl(200, 30%, 15%) 50%, hsl(186, 40%, 20%) 100%)' }}
    >
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"
          alt="Ocean phytoplankton microscopic view"
          className="w-full h-full object-cover opacity-25"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-blue-900/70 to-teal-900/80"></div>
      </div>

      {/* Content */}
      <div className="relative z-20 px-4 max-w-6xl mx-auto">
        <div className="text-center mb-16" data-aos="fade-down">
          <h2 className="font-poppins font-bold text-5xl md:text-7xl mb-6 glow-text">
            The Problem 🌊
          </h2>
          <p className="text-xl md:text-2xl text-cyan-100 font-montserrat mb-8">
            Understanding Phytoplankton: Ocean's Oxygen Factories
          </p>
        </div>

        {/* Statistical Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {/* Oxygen Production */}
          <div className="content-card p-8 rounded-2xl text-center" data-aos="fade-up" data-aos-delay="200">
            <div className="text-6xl mb-4">🌬️</div>
            <div className="text-4xl font-bold text-cyan-300 mb-2">50%</div>
            <h3 className="font-poppins font-semibold text-xl mb-3 text-cyan-300">Oxygen Production</h3>
            <p className="text-gray-300">
              Phytoplankton produce half of all the oxygen we breathe through photosynthesis - more than all terrestrial plants combined.
            </p>
          </div>

          {/* Food Chain Base */}
          <div className="content-card p-8 rounded-2xl text-center" data-aos="fade-up" data-aos-delay="400">
            <div className="text-6xl mb-4">🐠</div>
            <div className="text-4xl font-bold text-green-300 mb-2">95%</div>
            <h3 className="font-poppins font-semibold text-xl mb-3 text-green-300">Food Chain Foundation</h3>
            <p className="text-gray-300">
              95% of marine life depends directly or indirectly on phytoplankton as the foundation of the ocean food web.
            </p>
          </div>

          {/* Carbon Absorption */}
          <div className="content-card p-8 rounded-2xl text-center" data-aos="fade-up" data-aos-delay="600">
            <div className="text-6xl mb-4">🌍</div>
            <div className="text-4xl font-bold text-blue-300 mb-2">40%</div>
            <h3 className="font-poppins font-semibold text-xl mb-3 text-blue-300">Carbon Absorption</h3>
            <p className="text-gray-300">
              Phytoplankton absorb 40% of global CO₂ emissions, playing a crucial role in climate regulation.
            </p>
          </div>
        </div>

        {/* Infographic Section */}
        <div className="content-card p-8 rounded-2xl glow-border" data-aos="fade-up" data-aos-delay="800">
          <h3 className="font-poppins font-bold text-2xl text-center mb-8 text-cyan-300">
            How Phytoplankton Create Life 🔬
          </h3>
          <div className="grid md:grid-cols-4 gap-6 text-center">
            <div className="flex flex-col items-center">
              <div className="text-5xl mb-3">☀️</div>
              <p className="text-sm text-gray-300">Absorb Sunlight</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="text-5xl mb-3">💧</div>
              <p className="text-sm text-gray-300">Use CO₂ + Water</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="text-5xl mb-3">⚡</div>
              <p className="text-sm text-gray-300">Photosynthesis</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="text-5xl mb-3">🌬️</div>
              <p className="text-sm text-gray-300">Release Oxygen</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const SilentKillerSection = () => {
  return (
    <section
      id="microplastics-section"
      className="scroll-section pollution-gradient relative flex items-center justify-center overflow-hidden"
    >
      {/* Background image overlay */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1583212292454-1fe6229603b7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"
          alt="Microplastics pollution in ocean water"
          className="w-full h-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-slate-900/80 to-gray-900/90"></div>
      </div>

      {/* Content */}
      <div className="relative z-20 px-4 max-w-6xl mx-auto text-center">
        <div data-aos="fade-down" data-aos-duration="800">
          <h2 className="font-poppins font-bold text-5xl md:text-8xl mb-4">
            Silent Killer:{" "}
            <span className="glow-text text-red-400 animate-pulse-glow text-6xl md:text-9xl">MICROPLASTICS</span> ⚠️
          </h2>
          <p className="text-xl md:text-2xl mb-12 text-gray-300">
            The invisible enemy destroying our oxygen supply
          </p>
        </div>

        {/* Shocking Statistics */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {/* Annual Ocean Pollution */}
          <div className="content-card p-6 rounded-2xl" data-aos="fade-up" data-aos-delay="200">
            <div className="text-6xl mb-4">🚫</div>
            <div className="text-4xl font-bold text-red-400 mb-2">8 Million</div>
            <h3 className="font-poppins font-semibold text-xl mb-3 text-cyan-300">Tons of Plastic/Year</h3>
            <p className="text-gray-300">
              Every year, 8 million metric tons of plastic waste enters our oceans - equivalent to dumping a garbage truck of plastic every minute.
            </p>
          </div>

          {/* Microplastic Concentration */}
          <div className="content-card p-6 rounded-2xl" data-aos="fade-up" data-aos-delay="400">
            <div className="text-6xl mb-4">☠️</div>
            <div className="text-4xl font-bold text-orange-400 mb-2">5 Trillion</div>
            <h3 className="font-poppins font-semibold text-xl mb-3 text-red-300">Plastic Particles</h3>
            <p className="text-gray-300">
              Over 5 trillion plastic pieces are floating in our oceans, with microplastics found in 90% of sea salt and bottled water samples.
            </p>
          </div>

          {/* Phytoplankton Decline */}
          <div className="content-card p-6 rounded-2xl" data-aos="fade-up" data-aos-delay="600">
            <div className="text-6xl mb-4">📉</div>
            <div className="text-4xl font-bold text-yellow-400 mb-2">40%</div>
            <h3 className="font-poppins font-semibold text-xl mb-3 text-yellow-300">Decline Since 1950s</h3>
            <p className="text-gray-300">
              Phytoplankton populations have declined by 40% since the 1950s, directly threatening global oxygen production and marine ecosystems.
            </p>
          </div>
        </div>

        {/* How Microplastics Kill */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {/* Blocking Sunlight */}
          <div className="content-card p-6 rounded-2xl" data-aos="fade-up" data-aos-delay="700">
            <div className="text-6xl mb-4">🌑</div>
            <h3 className="font-poppins font-semibold text-xl mb-3 text-cyan-300">Blocking Sunlight</h3>
            <p className="text-gray-300">
              Microplastics form a surface layer that reduces sunlight penetration by up to 20%, directly impacting photosynthesis in phytoplankton.
            </p>
          </div>

          {/* Toxic Ingestion */}
          <div className="content-card p-6 rounded-2xl" data-aos="fade-up" data-aos-delay="800">
            <div className="text-6xl mb-4">🧪</div>
            <h3 className="font-poppins font-semibold text-xl mb-3 text-red-300">Toxic Ingestion</h3>
            <p className="text-gray-300">
              Phytoplankton mistake microplastics for food, ingesting toxic chemicals like BPA and phthalates that disrupt cellular functions.
            </p>
          </div>

          {/* Ocean Acidification */}
          <div className="content-card p-6 rounded-2xl" data-aos="fade-up" data-aos-delay="900">
            <div className="text-6xl mb-4">⚗️</div>
            <h3 className="font-poppins font-semibold text-xl mb-3 text-purple-300">Chemical Disruption</h3>
            <p className="text-gray-300">
              Plastic degradation releases chemicals that alter ocean pH levels, creating hostile environments for phytoplankton growth.
            </p>
          </div>
        </div>

        {/* Critical Alert */}
        <div data-aos="fade-up" data-aos-delay="1000" className="content-card p-8 rounded-2xl mb-8 glow-border border-red-500/50">
          <div className="text-6xl mb-4">🚨</div>
          <blockquote className="text-2xl md:text-3xl font-light text-red-100 italic mb-4">
            "If current trends continue, there will be more plastic than fish in the ocean by 2050"
          </blockquote>
          <p className="text-cyan-200">- World Economic Forum</p>
        </div>
      </div>
    </section>
  );
};

const ImpactSection = () => {
  return (
    <section className="scroll-section relative flex items-center justify-center overflow-hidden bg-gradient-to-b from-red-900/20 to-gray-900">
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1571771019784-3ff35f4f4277?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"
          alt="Dead fish and marine life affected by pollution"
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-red-900/60 to-gray-900/80"></div>
      </div>

      {/* Content */}
      <div className="relative z-20 px-4 max-w-6xl mx-auto">
        <div className="text-center mb-16" data-aos="fade-down">
          <h2 className="font-poppins font-bold text-5xl md:text-7xl mb-6 text-red-400 glow-text">
            The Impact 💀
          </h2>
          <p className="text-xl md:text-2xl text-red-200 font-montserrat">
            Consequences of the Microplastic Crisis
          </p>
        </div>

        {/* Impact Categories */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {/* Oxygen Crisis */}
          <div className="content-card p-8 rounded-2xl text-center border-red-500/30" data-aos="fade-up" data-aos-delay="200">
            <div className="text-6xl mb-4">🌬️</div>
            <div className="text-4xl font-bold text-red-400 mb-2">-50%</div>
            <h3 className="font-poppins font-semibold text-xl mb-3 text-red-300">Oxygen Crisis</h3>
            <p className="text-gray-300">
              With phytoplankton decline, global oxygen levels could drop by 50%, making large areas of Earth uninhabitable for human life.
            </p>
          </div>

          {/* Marine Extinction */}
          <div className="content-card p-8 rounded-2xl text-center border-orange-500/30" data-aos="fade-up" data-aos-delay="400">
            <div className="text-6xl mb-4">🐠</div>
            <div className="text-4xl font-bold text-orange-400 mb-2">1 Million</div>
            <h3 className="font-poppins font-semibold text-xl mb-3 text-orange-300">Species at Risk</h3>
            <p className="text-gray-300">
              Over 1 million marine species face extinction as the foundation of ocean food webs collapses from microplastic contamination.
            </p>
          </div>

          {/* Climate Chaos */}
          <div className="content-card p-8 rounded-2xl text-center border-yellow-500/30" data-aos="fade-up" data-aos-delay="600">
            <div className="text-6xl mb-4">🌍</div>
            <div className="text-4xl font-bold text-yellow-400 mb-2">+4°C</div>
            <h3 className="font-poppins font-semibold text-xl mb-3 text-yellow-300">Climate Chaos</h3>
            <p className="text-gray-300">
              Without phytoplankton's carbon absorption, global temperatures could rise by 4°C, triggering irreversible climate catastrophe.
            </p>
          </div>
        </div>

        {/* Timeline of Destruction */}
        <div className="content-card p-8 rounded-2xl glow-border mb-8" data-aos="fade-up" data-aos-delay="800">
          <h3 className="font-poppins font-bold text-2xl text-center mb-8 text-red-300">
            Timeline of Destruction ⏰
          </h3>
          <div className="grid md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-red-400 mb-2">2030</div>
              <p className="text-sm text-gray-300">Ocean plastic triples</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-400 mb-2">2040</div>
              <p className="text-sm text-gray-300">Phytoplankton drop 60%</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-yellow-400 mb-2">2050</div>
              <p className="text-sm text-gray-300">More plastic than fish</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-red-500 mb-2">2060</div>
              <p className="text-sm text-gray-300">Oxygen crisis begins</p>
            </div>
          </div>
        </div>

        {/* Call to Action Teaser */}
        <div className="text-center" data-aos="fade-up" data-aos-delay="1000">
          <div className="animate-bounce mb-4">
            <p className="text-cyan-300 text-xl">But we can still change this... ⬇️</p>
          </div>
        </div>
      </div>
    </section>
  );
};

const SolutionSection = () => {
  return (
    <section className="scroll-section solution-gradient relative flex items-center justify-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1618477247222-acbdb0e159b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"
          alt="Ocean cleanup and environmental conservation efforts"
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-emerald-900/80 to-teal-900/90"></div>
      </div>

      {/* Content */}
      <div className="relative z-20 px-4 max-w-6xl mx-auto">
        {/* Solution Header */}
        <div className="text-center mb-16" data-aos="fade-down">
          <h2 className="font-poppins font-bold text-5xl md:text-7xl mb-4 glow-text">
            The Solution: PhytoBolt ⚡
          </h2>
          <p className="text-xl md:text-2xl text-emerald-100 font-montserrat">
            <em>Turning Awareness into Action</em>
          </p>
        </div>

        {/* Solution Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {/* Awareness */}
          <div className="content-card p-8 rounded-2xl text-center hover:scale-105 transition-all duration-300 glow-border" data-aos="fade-up" data-aos-delay="200">
            <div className="text-6xl mb-4">🌍</div>
            <h3 className="font-poppins font-semibold text-xl mb-3 text-cyan-300">Awareness</h3>
            <p className="text-gray-300 mb-4">
              Interactive storytelling website that educates people about the critical role of phytoplankton and the microplastic threat.
            </p>
            <div className="text-2xl font-bold text-emerald-400">Education First</div>
          </div>

          {/* Action */}
          <div className="content-card p-8 rounded-2xl text-center hover:scale-105 transition-all duration-300 glow-border" data-aos="fade-up" data-aos-delay="400">
            <div className="text-6xl mb-4">💪</div>
            <h3 className="font-poppins font-semibold text-xl mb-3 text-green-300">Action</h3>
            <p className="text-gray-300 mb-4">
              Practical steps to reduce single-use plastics, participate in ocean cleanups, and make sustainable choices daily.
            </p>
            <div className="text-2xl font-bold text-green-400">Change Habits</div>
          </div>

          {/* Technology */}
          <div className="content-card p-8 rounded-2xl text-center hover:scale-105 transition-all duration-300 glow-border" data-aos="fade-up" data-aos-delay="600">
            <div className="text-6xl mb-4">⚡</div>
            <h3 className="font-poppins font-semibold text-xl mb-3 text-blue-300">Technology</h3>
            <p className="text-gray-300 mb-4">
              Gamified platform where users pledge to protect ocean oxygen factories and track their environmental impact.
            </p>
            <div className="text-2xl font-bold text-blue-400">Scale Impact</div>
          </div>
        </div>
      </div>
    </section>
  );
};

const ActionSection = () => {
  return (
    <section className="scroll-section relative flex items-center justify-center overflow-hidden bg-gradient-to-b from-green-900/30 to-emerald-900/50">
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1582408921715-18e7806365c1?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"
          alt="Hands holding bioluminescent organisms"
          className="w-full h-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-green-900/70 to-emerald-900/80"></div>
      </div>

      {/* Content */}
      <div className="relative z-20 px-4 max-w-6xl mx-auto">
        <div className="text-center mb-16" data-aos="fade-down">
          <h2 className="font-poppins font-bold text-5xl md:text-7xl mb-6 text-green-400 glow-text">
            What Can We Do? 🌱
          </h2>
          <p className="text-xl md:text-2xl text-green-200 font-montserrat">
            Every action counts. Every choice matters.
          </p>
        </div>

        {/* Action Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {/* Reduce Plastics */}
          <div className="content-card p-8 rounded-2xl text-center hover:scale-105 transition-all duration-300 border-green-500/40" data-aos="fade-up" data-aos-delay="200">
            <div className="text-6xl mb-4">🌍</div>
            <h3 className="font-poppins font-semibold text-xl mb-3 text-green-300">Reduce Plastics</h3>
            <ul className="text-gray-300 text-left space-y-2 mb-4">
              <li>✓ Use reusable bags and bottles</li>
              <li>✓ Choose glass over plastic containers</li>
              <li>✓ Avoid single-use packaging</li>
              <li>✓ Support plastic-free brands</li>
            </ul>
            <div className="text-lg font-bold text-green-400">Reduce by 80%</div>
          </div>

          {/* Support Cleanups */}
          <div className="content-card p-8 rounded-2xl text-center hover:scale-105 transition-all duration-300 border-cyan-500/40" data-aos="fade-up" data-aos-delay="400">
            <div className="text-6xl mb-4">🌊</div>
            <h3 className="font-poppins font-semibold text-xl mb-3 text-cyan-300">Support Cleanups</h3>
            <ul className="text-gray-300 text-left space-y-2 mb-4">
              <li>✓ Join beach cleanup drives</li>
              <li>✓ Volunteer with green organizations</li>
              <li>✓ Organize community cleanups</li>
              <li>✓ Support ocean conservation groups</li>
            </ul>
            <div className="text-lg font-bold text-cyan-400">Join 1000+ volunteers</div>
          </div>

          {/* Spread Awareness */}
          <div className="content-card p-8 rounded-2xl text-center hover:scale-105 transition-all duration-300 border-yellow-500/40" data-aos="fade-up" data-aos-delay="600">
            <div className="text-6xl mb-4">📢</div>
            <h3 className="font-poppins font-semibold text-xl mb-3 text-yellow-300">Spread Awareness</h3>
            <ul className="text-gray-300 text-left space-y-2 mb-4">
              <li>✓ Share with friends and family</li>
              <li>✓ Post on social media</li>
              <li>✓ Educate in schools and communities</li>
              <li>✓ Support environmental education</li>
            </ul>
            <div className="text-lg font-bold text-yellow-400">Reach millions</div>
          </div>
        </div>

        {/* Impact Statistics */}
        <div className="content-card p-8 rounded-2xl glow-border" data-aos="fade-up" data-aos-delay="800">
          <h3 className="font-poppins font-bold text-2xl text-center mb-8 text-green-300">
            Your Impact Potential 📊
          </h3>
          <div className="grid md:grid-cols-4 gap-6 text-center">
            <div>
              <div className="text-3xl font-bold text-green-400 mb-2">500kg</div>
              <p className="text-sm text-gray-300">Plastic saved per person/year</p>
            </div>
            <div>
              <div className="text-3xl font-bold text-cyan-400 mb-2">50m³</div>
              <p className="text-sm text-gray-300">Ocean cleaned per volunteer</p>
            </div>
            <div>
              <div className="text-3xl font-bold text-yellow-400 mb-2">1000+</div>
              <p className="text-sm text-gray-300">People reached per share</p>
            </div>
            <div>
              <div className="text-3xl font-bold text-emerald-400 mb-2">5%</div>
              <p className="text-sm text-gray-300">Oxygen production protected</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const HopeSection = () => {
  return (
    <section className="scroll-section relative flex items-center justify-center overflow-hidden bg-gradient-to-b from-blue-900/30 to-cyan-900/50">
      {/* Background comparison */}
      <div className="absolute inset-0 flex">
        {/* Healthy Ocean */}
        <div className="w-1/2 relative">
          <img
            src="https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"
            alt="Healthy ocean with vibrant marine life"
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-transparent to-blue-900/50"></div>
          <div className="absolute top-8 left-8 content-card p-4 rounded-xl">
            <h4 className="text-green-400 font-bold text-xl">Healthy Ocean 🌊</h4>
            <p className="text-green-200">Thriving phytoplankton</p>
          </div>
        </div>

        {/* Polluted Ocean */}
        <div className="w-1/2 relative">
          <img
            src="https://images.unsplash.com/photo-1621451537084-482c73073a0f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"
            alt="Plastic-choked ocean"
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-l from-transparent to-blue-900/50"></div>
          <div className="absolute top-8 right-8 content-card p-4 rounded-xl">
            <h4 className="text-red-400 font-bold text-xl">Plastic-Choked 🛑</h4>
            <p className="text-red-200">Dying ecosystems</p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="relative z-20 px-4 max-w-4xl mx-auto text-center">
        <div data-aos="fade-up" data-aos-duration="1000">
          <h2 className="font-poppins font-bold text-5xl md:text-7xl mb-6 text-cyan-400 glow-text">
            Hope is Alive ✨
          </h2>
          <div className="content-card p-8 rounded-2xl glow-border mb-8">
            <p className="text-xl md:text-2xl text-cyan-100 mb-6">
              Recovery is possible. When we act together, oceans heal, phytoplankton thrive, and life returns.
            </p>
            <blockquote className="text-lg text-gray-300 italic">
              "The best time to plant a tree was 20 years ago. The second best time is now. The same applies to saving our oceans."
            </blockquote>
          </div>

          {/* Success Stories */}
          <div className="grid md:grid-cols-3 gap-6">
            <div className="content-card p-6 rounded-xl" data-aos="fade-up" data-aos-delay="200">
              <div className="text-4xl mb-3">🐋</div>
              <h4 className="font-bold text-cyan-300 mb-2">Marine Recovery</h4>
              <p className="text-sm text-gray-300">Protected areas show 30% increase in marine biodiversity</p>
            </div>
            <div className="content-card p-6 rounded-xl" data-aos="fade-up" data-aos-delay="400">
              <div className="text-4xl mb-3">♻️</div>
              <h4 className="font-bold text-green-300 mb-2">Plastic Alternatives</h4>
              <p className="text-sm text-gray-300">Biodegradable plastics reduce ocean pollution by 60%</p>
            </div>
            <div className="content-card p-6 rounded-xl" data-aos="fade-up" data-aos-delay="600">
              <div className="text-4xl mb-3">🌱</div>
              <h4 className="font-bold text-emerald-300 mb-2">Restoration Success</h4>
              <p className="text-sm text-gray-300">Ocean cleanup projects remove 1000 tons of plastic yearly</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const PledgeSection = () => {
  const [isPledged, setIsPledged] = useState(false);
  
  const handlePledge = () => {
    setIsPledged(true);
    console.log("PhytoHero pledge activated!");
  };

  return (
    <section className="scroll-section relative flex items-center justify-center overflow-hidden bg-gradient-to-b from-purple-900/30 to-indigo-900/50">
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"
          alt="Bioluminescent phytoplankton"
          className="w-full h-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-purple-900/70 to-indigo-900/80"></div>
      </div>

      {/* Content */}
      <div className="relative z-20 px-4 max-w-4xl mx-auto text-center">
        <div data-aos="fade-up" data-aos-duration="1000">
          <h2 className="font-poppins font-bold text-5xl md:text-7xl mb-8 text-purple-400 glow-text">
            PhytoHero Pledge 🫱‍🫲
          </h2>
          
          {/* Pledge Box */}
          <div className={`content-card p-8 rounded-2xl mb-8 transition-all duration-500 ${isPledged ? 'glow-border border-green-500/50 bg-green-900/20' : 'glow-border'}`}>
            <h3 className="font-poppins font-bold text-2xl mb-6 text-cyan-300">The PhytoHero Oath</h3>
            <div className="text-lg text-cyan-100 space-y-4 mb-8">
              <p>"I pledge to protect the ocean's oxygen factories."</p>
              <p>"I will reduce single-use plastics in my daily life."</p>
              <p>"I will spread awareness about the microplastic crisis."</p>
              <p>"I will support ocean conservation efforts."</p>
              <p>"I am a PhytoHero, guardian of Earth's breath."</p>
            </div>
            
            <button
              onClick={handlePledge}
              className={`px-12 py-4 rounded-full text-xl font-bold transition-all duration-500 transform ${
                isPledged 
                  ? 'bg-green-500 text-white scale-110 animate-pulse-glow' 
                  : 'bg-gradient-to-r from-purple-500 to-cyan-500 hover:from-purple-400 hover:to-cyan-400 hover:scale-105'
              }`}
              disabled={isPledged}
            >
              {isPledged ? '✅ I Am a PhytoHero!' : 'I Am a PhytoHero!'}
            </button>
            
            {isPledged && (
              <div className="mt-6 text-green-300 animate-float">
                <p className="text-xl">🎉 Welcome to the PhytoHero movement!</p>
                <p className="text-sm mt-2">You're now part of the solution to save our ocean's oxygen.</p>
              </div>
            )}
          </div>

          {/* Stats */}
          {isPledged && (
            <div className="content-card p-6 rounded-2xl" data-aos="fade-up" data-aos-delay="500">
              <h4 className="font-bold text-cyan-300 mb-4">PhytoHero Community Impact</h4>
              <div className="grid md:grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-green-400">10,000+</div>
                  <p className="text-sm text-gray-300">PhytoHeroes</p>
                </div>
                <div>
                  <div className="text-2xl font-bold text-cyan-400">500,000kg</div>
                  <p className="text-sm text-gray-300">Plastic Prevented</p>
                </div>
                <div>
                  <div className="text-2xl font-bold text-purple-400">25%</div>
                  <p className="text-sm text-gray-300">Awareness Increase</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

const TeamSection = () => {
  return (
    <section className="scroll-section relative flex items-center justify-center overflow-hidden bg-gradient-to-b from-indigo-900/30 to-purple-900/50">
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"
          alt="Technology and innovation background"
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-indigo-900/70 to-purple-900/80"></div>
      </div>

      {/* Content */}
      <div className="relative z-20 px-4 max-w-6xl mx-auto">
        <div className="text-center mb-16" data-aos="fade-down">
          <h2 className="font-poppins font-bold text-5xl md:text-7xl mb-6 text-purple-400 glow-text">
            Team Section 👩‍💻👨‍🔬
          </h2>
          <p className="text-xl md:text-2xl text-purple-200 font-montserrat">
            The PhytoBolt Creators
          </p>
        </div>

        {/* Team Cards */}
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-16">
          {/* Satviga */}
          <div className="content-card p-8 rounded-2xl text-center hover:scale-105 transition-all duration-300 glow-border border-cyan-500/40" data-aos="fade-up" data-aos-delay="200">
            <div className="text-6xl mb-4">👩‍💻</div>
            <h3 className="font-poppins font-bold text-2xl mb-2 text-cyan-300">Satviga</h3>
            <p className="text-cyan-200 font-medium mb-4 text-lg">Website Creator & Technology Lead</p>
            <p className="text-gray-300 mb-6">
              Passionate about marine conservation and innovative technology solutions for environmental challenges. 
              Dedicated to building platforms that raise awareness and inspire action for ocean preservation.
            </p>
            <div className="flex justify-center space-x-4">
              <div className="bg-cyan-500/20 px-3 py-1 rounded-full text-cyan-300 text-sm">React</div>
              <div className="bg-cyan-500/20 px-3 py-1 rounded-full text-cyan-300 text-sm">Marine Tech</div>
              <div className="bg-cyan-500/20 px-3 py-1 rounded-full text-cyan-300 text-sm">UI/UX</div>
            </div>
          </div>

          {/* Sanjay */}
          <div className="content-card p-8 rounded-2xl text-center hover:scale-105 transition-all duration-300 glow-border border-green-500/40" data-aos="fade-up" data-aos-delay="400">
            <div className="text-6xl mb-4">👨‍🔬</div>
            <h3 className="font-poppins font-bold text-2xl mb-2 text-green-300">Sanjay</h3>
            <p className="text-green-200 font-medium mb-4 text-lg">Website Creator & Research Lead</p>
            <p className="text-gray-300 mb-6">
              Dedicated to developing sustainable solutions that protect our planet's most vulnerable ecosystems. 
              Specializes in environmental research and data-driven approaches to ocean conservation.
            </p>
            <div className="flex justify-center space-x-4">
              <div className="bg-green-500/20 px-3 py-1 rounded-full text-green-300 text-sm">Research</div>
              <div className="bg-green-500/20 px-3 py-1 rounded-full text-green-300 text-sm">Data Science</div>
              <div className="bg-green-500/20 px-3 py-1 rounded-full text-green-300 text-sm">Ecology</div>
            </div>
          </div>
        </div>

        {/* Mission Statement */}
        <div className="content-card p-8 rounded-2xl glow-border max-w-4xl mx-auto" data-aos="fade-up" data-aos-delay="600">
          <div className="text-center">
            <h3 className="font-poppins font-bold text-2xl mb-6 text-purple-300">Our Mission</h3>
            <blockquote className="text-xl md:text-2xl font-light text-purple-100 italic mb-6">
              "We built PhytoBolt to turn awareness into action—because the ocean can't wait."
            </blockquote>
            <p className="text-gray-300 text-lg">
              Together, we're creating innovative solutions to protect the microscopic heroes that produce half of Earth's oxygen. 
              Through technology, education, and community action, we're fighting the invisible threat of microplastics.
            </p>
          </div>
        </div>

        {/* Contact & Social */}
        <div className="text-center mt-12" data-aos="fade-up" data-aos-delay="800">
          <h4 className="font-poppins font-bold text-xl mb-6 text-purple-300">Connect with PhytoBolt</h4>
          <div className="flex justify-center space-x-6">
            <button className="bg-blue-600 hover:bg-blue-500 px-6 py-3 rounded-full transition-all duration-300 transform hover:scale-105">
              Twitter 🐦
            </button>
            <button className="bg-pink-600 hover:bg-pink-500 px-6 py-3 rounded-full transition-all duration-300 transform hover:scale-105">
              Instagram 📸
            </button>
            <button className="bg-blue-700 hover:bg-blue-600 px-6 py-3 rounded-full transition-all duration-300 transform hover:scale-105">
              LinkedIn 💼
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-slate-900 py-12 text-center border-t border-cyan-500/20">
      <div className="max-w-6xl mx-auto px-4">
        {/* Main Footer Content */}
        <div className="flex items-center justify-center mb-6">
          <span className="text-5xl mr-4 animate-pulse">🌎</span>
          <div>
            <p className="text-2xl font-bold text-cyan-300 mb-2">Built with 💚 for the Ocean</p>
            <p className="text-lg text-gray-300">HackTheOcean 2025</p>
          </div>
        </div>

        {/* Contact Info */}
        <div className="text-gray-400 mb-6">
          <a
            href="mailto:contact@phytobolt.org"
            className="hover:text-cyan-300 transition-colors text-lg"
          >
            contact@phytobolt.org
          </a>
          <span className="mx-4">•</span>
          <span className="text-cyan-300 text-lg font-medium">#SaveOurOxygen #PhytoBolt</span>
        </div>

        {/* Call to Action */}
        <div className="content-card p-6 rounded-2xl max-w-2xl mx-auto mb-6">
          <p className="text-cyan-100 text-lg mb-4">
            "Every second, microplastics threaten the oxygen you breathe. Join the PhytoHero movement today."
          </p>
          <div className="flex justify-center space-x-4">
            <div className="text-sm">
              <span className="text-green-400 font-bold">50%</span> 
              <span className="text-gray-300"> of your oxygen comes from phytoplankton</span>
            </div>
            <div className="text-sm">
              <span className="text-red-400 font-bold">8M tons</span> 
              <span className="text-gray-300"> of plastic enter oceans yearly</span>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-700 pt-6">
          <p className="text-sm text-gray-500 mb-2">© 2025 PhytoBolt. All rights reserved.</p>
          <p className="text-xs text-gray-600">
            This project was created to raise awareness about microplastics' impact on marine phytoplankton and global oxygen production.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default function Home() {
  useEffect(() => {
    // Initialize AOS animations
    if (typeof window !== "undefined" && window.AOS) {
      window.AOS.init({
        duration: 800,
        easing: "ease-in-out",
        once: true,
        offset: 100,
      });
    }

    // Add scroll progress indicator
    const createScrollProgress = () => {
      const progressBar = document.createElement("div");
      progressBar.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 0%;
        height: 3px;
        background: linear-gradient(90deg, #22D3EE, #10B981);
        z-index: 9999;
        transition: width 0.3s ease;
      `;
      document.body.appendChild(progressBar);

      const handleScroll = () => {
        const scrolled =
          (window.pageYOffset / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
        progressBar.style.width = scrolled + "%";
      };

      window.addEventListener("scroll", handleScroll);

      return () => {
        window.removeEventListener("scroll", handleScroll);
        if (document.body.contains(progressBar)) {
          document.body.removeChild(progressBar);
        }
      };
    };

    // Add floating particles to sections
    const createFloatingParticles = () => {
      const sections = document.querySelectorAll(".scroll-section");
      sections.forEach((section) => {
        for (let i = 0; i < 8; i++) {
          const particle = document.createElement("div");
          particle.className = "floating-particle";
          particle.style.top = Math.random() * 100 + "%";
          particle.style.animationDelay = -Math.random() * 15 + "s";
          particle.style.animationDuration = 10 + Math.random() * 10 + "s";
          section.appendChild(particle);
        }
      });
    };

    const cleanupProgress = createScrollProgress();
    createFloatingParticles();

    console.log("PhytoBolt: Ocean oxygen awareness system initialized 🌊⚡");

    return () => {
      cleanupProgress();
    };
  }, []);

  return (
    <div className="font-inter text-white overflow-x-hidden">
      <HeroSection />
      <ProblemSection />
      <SilentKillerSection />
      <ImpactSection />
      <SolutionSection />
      <ActionSection />
      <HopeSection />
      <PledgeSection />
      <TeamSection />
      <Footer />
    </div>
  );
}
